﻿// op-gaotong.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/core/core.hpp>   
#include <opencv2/highgui/highgui.hpp>   
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;

int main()
{
	Mat src = imread("2.jpg", IMREAD_GRAYSCALE);//将导入图片转变成灰度图片
	if (src.empty())
	{
		return -1;
	}
	
	int w = getOptimalDFTSize(src.cols);//返回给定向量尺寸的傅里叶最优尺寸大小
	int h = getOptimalDFTSize(src.rows);
	//把灰度图像放在左上角,在右边和下边扩展图像,扩展部分填充为0;
	Mat dst;
	//将原始图像拷贝到目的图像中央
	copyMakeBorder(src, dst, 0, h - src.rows, 0, w - src.cols, BORDER_CONSTANT, Scalar::all(0));
	dst.convertTo(dst, CV_32FC1);
	for (int i = 0; i < dst.rows; i++)
	{
		float* ptr = dst.ptr<float>(i);
		for (int j = 0; j < dst.cols; j++)
			ptr[j] *= pow(-1, i + j);//幂函数（-1）^(i+j)
	}
	//傅里叶变换部分
	//这里是获取了两个Mat,一个用于存放dft变换的实部，一个用于存放虚部,初始的时候,实部就是图像本身,虚部全为零
	Mat plane[] = { dst,Mat::zeros(dst.size(),CV_32F) };
	Mat complexImg;
	merge(plane, 2, complexImg);//单通道的mat融合成一个多通道的mat
	dft(complexImg, complexImg);//对上边合成的mat进行傅里叶变换，傅里叶变换结果为复数.通道1存的是实部,通道二存的是虚部
	split(complexImg, plane);//把变换后的结果分割到两个mat,一个实部,一个虚部,方便后续操作
	magnitude(plane[0], plane[1], plane[0]);//计算dft变换后的幅值，我们可以用对数尺度来替换线性尺度,以便于显示幅值
	plane[0] += Scalar::all(1);
	log(plane[0], plane[0]);
	normalize(plane[0], plane[0], 1, 0, NORM_MINMAX);//此时plane[0]表示dft图像

	//高通滤波器
	Mat lowBlur(dst.size(), CV_32FC2);
	double D1 ;//滤波器半径
	cout << "输入高通滤波器半径（推荐20）：";
	cin >> D1;
	for (int i = 0; i < dst.rows; i++) {
		float* p = lowBlur.ptr<float>(i);
		for (int j = 0; j < dst.cols; j++) {
			double d = sqrt(pow((i - dst.rows / 2), 2) + pow((j - dst.cols / 2), 2));//分子,计算pow必须为float型
			if (d <= D1) {//低频部分设置为0
				p[2 * j + 1] = 0;
				p[2 * j] = 0;
			}
			else {//保留高频部分
				p[2 * j] = 1;
				p[2 * j + 1] = 1;
			}
		}
	}
	multiply(complexImg, lowBlur, lowBlur);
	idft(lowBlur, lowBlur);//逆变换
	split(lowBlur, plane);

	magnitude(plane[0], plane[1], plane[0]);
	normalize(plane[0], plane[0], 1, 0, NORM_MINMAX);//归一化
	imshow("原始图片灰度图像", src);
	imshow("高通滤波图片", plane[0]);
	waitKey();
	return 0;
}

