﻿// op-weicaise.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/core/core.hpp>   
#include <opencv2/highgui/highgui.hpp>   

using namespace std;  //省去屏幕输出函数cout前的std::
using namespace cv;   // 省去函数前面加cv::的必要性

//本函数可对位深度为8或16的图片进行处理
int main()
{
	Mat src = imread("ik_beijing_p.bmp", cv::IMREAD_LOAD_GDAL | cv::IMREAD_ANYDEPTH);
	cout << src.depth();//输出位深度值
	int a = src.depth();
	if (a == 0)//若位深度为8或24，可对灰度图像处理，三通道即彩色图像无法进行增强
	{
		//定义增强图片的RGB三通道
		Mat R = src.clone();
		Mat G = src.clone();
		Mat B = src.clone();
		
		//进行灰度线性变换操作
		int rows = src.rows;
		int cols = src.cols;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				int current = src.at<uchar>(i, j);
				if (0 < current && current <= 64)
				{
					R.at<uchar>(i, j) = 0;
					G.at<uchar>(i, j) = 4 * current;
					B.at<uchar>(i, j) = 255;
				}
				else if (64 < current && current <= 128)
				{
					R.at<uchar>(i, j) = 0;
					G.at<uchar>(i, j) = 255;
					B.at<uchar>(i, j) = -4 * (current - 64) + 255;
				}
				else if (128 < current && current <= 192)
				{
					R.at<uchar>(i, j) = 4 * (current - 128);
					G.at<uchar>(i, j) = 255;
					B.at<uchar>(i, j) = 0;
				}
				else
				{
					R.at<uchar>(i, j) = 255;
					G.at<uchar>(i, j) = -4 * (current - 255);
					B.at<uchar>(i, j) = 0;
				}
			}
		}

		Mat channels[3];  //定义对象数组，分别存储三个通道
		Mat dst;      //融合三个通道，存储在一个Mat里
		channels[0] = B;
		channels[1] = G;
		channels[2] = R;

		merge(channels, 3, dst);
		imshow("原图", src);
		imshow("效果图", dst);
		waitKey(0);
		return 0;
	}

	else if (a == 2) //若图片位深度为16，进行以下操作
	{
		Mat image(src.rows, src.cols, CV_16U);//强制转换位16位
		for (int i = 0; i < image.rows; i++)
		{
			for (int j = 0; j < image.cols; j++)
			{
				image.at<short>(i, j) = src.at<short>(i, j);//16位图对应的short类型
			}
		}
		//同样定义RGB深度为16
		Mat R(image.rows, image.cols, CV_16U);
		Mat G(image.rows, image.cols, CV_16U);
		Mat B(image.rows, image.cols, CV_16U);
		R = image.clone();
		G = image.clone();
		B = image.clone();

		int rows = image.rows;
		int cols = image.cols;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				int current = image.at<short>(i, j);
				if (current >= 0 && current <= 16448)
				{
					R.at<short>(i, j) = 0;
					G.at<short>(i, j) = 4 * current;
					B.at<short>(i, j) = 65535;
				}
				else if (16448 < current && current <= 32896)
				{
					R.at<short>(i, j) = 0;
					G.at<short>(i, j) = 65535;
					B.at<short>(i, j) = (-4) * (current - 32896);
				}
				else if (32896 < current && current <= 49344)
				{
					R.at<short>(i, j) = 4 * (current - 32896);
					G.at<short>(i, j) = 65535;
					B.at<short>(i, j) = 0;
				}
				else
				{
					R.at<short>(i, j) = 65535;
					G.at<short>(i, j) = (-4) * (current - 65535);
					B.at<short>(i, j) = 0;
				}

			}
		}
		Mat imgArray[3];
		imgArray[0] = R;
		imgArray[1] = G;
		imgArray[2] = B;
		Mat dst16;
		merge(imgArray, 3, dst16);
		imshow("原图", src);
		imshow("效果图", dst16);
		waitKey(0);
		return 0;
	}

	else 
    {
	  cout << "图片位深度不为8或16，不能进行伪彩色增强"; 
	  waitKey(0);
	  return 0;
    };	
}


