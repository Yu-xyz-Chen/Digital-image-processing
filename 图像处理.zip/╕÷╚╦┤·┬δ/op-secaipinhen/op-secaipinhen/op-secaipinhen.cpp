﻿// op-secaipinhen.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include "opencv2/highgui/highgui.hpp"

using namespace cv;
using namespace std;

//完美反射函数，程序运行后输入选择的ratio值进行色彩平衡
void WanmeiFanshe(Mat&src,Mat&dst,float ratio)
{
	int row = src.rows;
	int col = src.cols;
	dst.create(row, col, CV_8UC3);//定义色彩平衡后图片大小与原始图片相同
	
	int HistRGB[767] = { 0 };//像素和的数量
	int Max = 0;

	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++) 
		{
			//找到图像中最亮点，定义为最大值
			Max = max(Max, (int)src.at<Vec3b>(i, j)[0]);
			Max = max(Max, (int)src.at<Vec3b>(i, j)[1]);
			Max = max(Max, (int)src.at<Vec3b>(i, j)[2]);
			//计算像素的和
			int sum = src.at<Vec3b>(i, j)[0] + src.at<Vec3b>(i, j)[1] + src.at<Vec3b>(i, j)[2];
			//保存像素和的数量
			HistRGB[sum]++;
		}
	}
	
	//计算阈值
	ratio = row * col * ratio;//ratio可定义为0.05，即计算其前5%，也可依据其他ratio确定阈值

	int a = 0;
	int sum = 0;
	for (int i = 766; i >= 0; i--) {
		sum += HistRGB[i];

		if (sum > ratio) 
		{
			a = i;//a为阈值
			break;
		}
	}

	int SumB = 0;
	int SumG = 0;
	int SumR = 0;
	int b = 0;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			int sumP = src.at<Vec3b>(i, j)[0] + src.at<Vec3b>(i, j)[1] + src.at<Vec3b>(i, j)[2];
			if (sumP > a) //遍历图像中的每个点，计算R+G+B大于T的所有点的R、G、B分量的累积和、均值
			{
				//计算R.G.B分量的和
				SumB += src.at<Vec3b>(i, j)[0];
				SumG += src.at<Vec3b>(i, j)[1];
				SumR += src.at<Vec3b>(i, j)[2];
				b++;
			}
		}
	}
	// 计算R + G + BR + G + B大于 T 的所有点的R、G、B分量的累积和的平均值
	float AvgB = SumB/ b;
	float AvgG = SumG/ b;
	float AvgR = SumR/ b;

	//将每一个像素量化到[0,255]
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			int Blue = src.at<Vec3b>(i, j)[0] * Max / AvgB;
			int Green = src.at<Vec3b>(i, j)[1] * Max / AvgG;
			int Red = src.at<Vec3b>(i, j)[2] * Max / AvgR;
			
			if (Red > 255) Red = 255;
			else if (Red < 0)Red = 0;
			
			if (Green > 255) Green = 255;
			else if (Green < 0) Green = 0;
			
			if (Blue > 255)Blue = 255;
			else if (Blue < 0) Blue = 0;
			
			dst.at<Vec3b>(i, j)[0] = Blue;
			dst.at<Vec3b>(i, j)[1] = Green;
			dst.at<Vec3b>(i, j)[2] = Red;
		}
	}
	imshow("原始图片", src);
	imshow("色彩平衡图片", dst);
}

int main() 
{
	Mat src = imread("ik_beijing_c.bmp");
	Mat dst;
	float ratio;
	cout << "输入Ratio（推荐0.05或0.1）:";
	cin >> ratio;
	WanmeiFanshe(src,dst,ratio);
	waitKey(0);
}


