﻿// op-zhongzhi.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/core/core.hpp>   
#include <opencv2/highgui/highgui.hpp>   
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;


//此函数返回各像素点中值
static bool median(Mat& src, Mat& dst, int Size)
{
	int cols = dst.cols;
	int rows = dst.rows;
	for (int i = 0; i < rows; i++)
	{
		uchar* data = dst.ptr<uchar>(i);//使用指针访问
		for (int j = 0; j < cols; j++)
		{
			int* values = new int[Size * 4 + 4 * Size * Size + 1];
			int num = 0;
			for (int m = -1 * Size; m <= Size; m++)
				for (int n = -1 * Size; n <= Size; n++)
				{
					values[num] = src.ptr<uchar>(i + Size + m)[j + Size + n];
					num++;
				}
			for (int a = 0; a < num; a++)
			{
				for (int b = a + 1; b < num; b++)
				{
					if (values[a] > values[b])
					{
						int temp = values[b];
						values[b] = values[a];
						values[a] = temp;
					}
				}
			}
			dst.ptr<uchar>(i)[j] = values[num / 2];
			delete values;
		}
	}
	return true;
}

static bool mediablur(Mat& src, Mat& dst, int radius)//中值滤波
{
	if (radius % 2 == 0)//偶数窗口值无法进行中值滤波
		return false;
	int r = radius / 2;//半径大小
	dst = src.clone();
	Mat resizeSrc;//中值滤波器
	copyMakeBorder(src, resizeSrc, r, r, r, r, cv::BORDER_REPLICATE );
	static int channels = src.channels();//判断通道数
	if (channels == 1)//灰度图像
	{
		median(resizeSrc, dst, r);
		return true;
	}
	else if (channels == 3)//彩色图像
	{
		Mat srcMat[3];
		Mat dstMat[3];
		split(resizeSrc, srcMat);
		split(dst, dstMat);
		for (int i = 0; i < 3; i++)
		{
			median(srcMat[i], dstMat[i], r);
		}
		merge(dstMat, 3, dst);
		return true;
	}
	else
	{
		return false;
	}
}

int main()
{
    Mat src = imread("ik_beijing_p.bmp");
	Mat dst;
    if (!src.data)
        return -1;
	int radius ;
    cout << "请输入中值滤波尺寸大小（奇数-推荐5）：";
	cin >> radius;
	cout << "程序运行需要一段时间，请耐心等待";
   int flag = mediablur( src,dst,radius);
   if (flag = 1) {
	   imshow("原始图像", src);
	   imshow("中值滤波", dst);
   }
   else cout << "失败";
    waitKey(0);
    return 0;
}
