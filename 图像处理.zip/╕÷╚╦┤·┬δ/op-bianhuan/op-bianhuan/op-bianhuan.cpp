﻿// op-bianhuan.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <opencv2/core/core.hpp>   
#include <opencv2/highgui/highgui.hpp>   
#include <opencv2\imgproc\imgproc.hpp>

using namespace std;
using namespace cv;
//定义线性变换函数
Mat test(Mat srcImage, float k, float b)
{
    if (srcImage.empty()) {
        cout << "图片打开失败" << endl;
    }
    const int nRows = srcImage.rows;
    const int nCols = srcImage.cols;
    Mat resultImage = Mat::zeros(srcImage.size(), srcImage.type());//定义变换后图片大小与类型
    // 图像元素遍历
    for (int i = 0; i < nRows; i++)
    {
        for (int j = 0; j < nCols; j++)
        {
            for (int c = 0; c < 3; c++)//如果源图像是灰度图,那么把这里改为c<1即可
            {
                // 矩阵at操作，检查下标防止越界，saturate_cast防止数据溢出
                resultImage.at<Vec3b>(i, j)[c] =saturate_cast<uchar>(k *(srcImage.at<Vec3b>(i, j)[c]) + b);
            }
        }
    }
    return resultImage;//返回变换图片
}

int main()
{
    Mat srcImage = imread("ik_beijing_p.bmp");
    if (!srcImage.data)
        return -1;
  
    //定义变换系数
    double k, b;
    cout << "请输入变换系数k和b：";
    cin >> k >> b;
    //调用变换函数
    Mat new_image = test(srcImage, k, b);
    imshow("srcImage", srcImage);
    imshow("dst", new_image);
    waitKey(0);
    return 0;
}




